<div class="sidebar">
    <h1>CRUD Barang</h1>
    <a href="../index.php">Profile</a>
    <a href="index.php">Daftar Barang</a>
    <a href="add.php">Tambah Barang</a>
    <a href="../logout.php">Logout</a>
</div>