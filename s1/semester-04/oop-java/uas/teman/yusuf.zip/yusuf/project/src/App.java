package src;

import src.view.FrameSuplayer;

public class App {

    public static void main(String[] args) {
        FrameSuplayer app = new FrameSuplayer();
        app.setVisible(true);
    }
}
