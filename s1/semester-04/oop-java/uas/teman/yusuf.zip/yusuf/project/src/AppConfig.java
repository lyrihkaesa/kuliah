package src;

public class AppConfig {
    public static String NIM = "A12.2020.06498";
    public static String FULLNAME_AUTHOR = "Yusuf Nasrulloh";
    public static String CREATEDBY = "Create By " + FULLNAME_AUTHOR + " dan " + NIM;

    public static String HOST = "localhost";
    public static String PORT = "3306";
    public static String DATABASE = "kuliah_pbo_6498";
    public static String USERNAME = "root";
    public static String PASSWORD = "";

}
