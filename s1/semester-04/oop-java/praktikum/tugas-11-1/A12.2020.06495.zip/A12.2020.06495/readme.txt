Catatan:
- Saya menggunakan driver mysql connector terbaru.
- Saya menggunakan konsep MVC (Model, View, Controller)
    - Model = Entity + Repository
    - View = View
    - Controller = Service + Util
- Jika ingin menjalankan aplikasi anda harus membuat database terlebih dahulu.
- Import backup.sql pada PHPMyAdmin atau Database clien lainnya.
- Jalankan program App.java atau FrameMenu.java.
- Selesai

Nama File
- Saya menggunakan penamaan yang mudah dimengerti, contoh:
    - FMenu = FrameMenu
    - FJual = FrameJual

