package src.service;

public interface TransactionService {
}
