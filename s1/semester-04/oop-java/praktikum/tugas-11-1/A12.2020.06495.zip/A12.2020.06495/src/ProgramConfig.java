package src;

public class ProgramConfig {

    public static String HOST = "localhost";
    public static String PORT = "3306";
    public static String DATABASE = "pbo_kukuh06495";
    public static String USERNAME = "root";
    public static String PASSWORD = "";

    public static String NIM = "A12.2020.06495";
    public static String FULLNAME_AUTHOR = "Kukuh Setya Arumansyah";
    public static String AUTHOR = NIM + "-" + FULLNAME_AUTHOR;

    public static String[] PROGRAM_TITLE = {
            "Program Pegawai | " + AUTHOR,
            "Program Barang | " + AUTHOR,
            "Menu Penjualan",
            "Transaksi Penjualan | " + AUTHOR
    };

}
