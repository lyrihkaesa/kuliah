package src;

import src.view.FrameMenu;

public class App {

    public static void main(String[] args) {
        FrameMenu app = new FrameMenu();
        app.setVisible(true);
    }
}
