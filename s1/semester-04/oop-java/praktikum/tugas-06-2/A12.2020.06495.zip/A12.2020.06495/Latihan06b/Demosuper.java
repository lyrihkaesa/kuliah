package Latihan06b;

public class Demosuper {
    public static void main(String[] args) {
        Employee dian = new Employee();
        dian.showInfo();
    }

}
