public class Latihan01d {
    public static void main(String[] args) {
        System.out.println("Nama            : Namanya Siapa");
        System.out.println("Jenis Kelamin   : Pria");
        System.out.println("Alamat          : Jl. apa sesuikan");
        System.out.println("Kota            : Semarang");
        System.out.println("Telpon          : 081512345678");
    }
}
