public class Latihan01c {
    public static void main(String[] args) {
        int a = 0;
        System.out.println("a   : " + a);
        System.out.println("a++ : " + a++);
        System.out.println("a   : " + a);
        System.out.println("++a   : " + ++a);
        System.out.println("a   : " + a);
        System.out.println("a--   : " + a--);
        System.out.println("a   : " + a);
        System.out.println("--a   : " + --a);
        System.out.println("a   : " + a);
    }
}
