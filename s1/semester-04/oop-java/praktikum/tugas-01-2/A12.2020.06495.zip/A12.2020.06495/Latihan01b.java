public class Latihan01b {
    public static void main(String[] args) {
        System.out.println("Hasil 1 : " + 1 + 1);
        System.out.println("Hasil 1 : " + (1 + 1));
        System.out.println(1 + 1);
        System.out.println("1" + 1);
        System.out.println(1 + "1");
        System.out.println("1 + 1");
    }
}
