Catatan:
- Saya menggunakan driver mysql connector terbaru.
- Saya menggunakan konsep MVC
- Jika ingin menjalankan aplikasi anda harus membuat database terlebih dahulu.
- Import PegawaiDanBarang.sql pada PHPMyAdmin atau Database clien lainnya.
- Jalankan program App.java atau FrameMenu.java.
- Selesai
