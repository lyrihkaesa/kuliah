public class Latihan02c {
  public static void main(String[] args) {
    String angka = "1010";

    int angka2 = Integer.valueOf(angka);

    System.out.println(angka + 10); // Output: 101010
    System.out.println(angka2 + 10); // Output: 1020
  }
}
