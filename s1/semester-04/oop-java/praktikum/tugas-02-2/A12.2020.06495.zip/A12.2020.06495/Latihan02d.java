public class Latihan02d {
  public static void main(String[] args) {
    int panjang, lebar, luas;

    panjang = 10;
    lebar = 15;

    luas = panjang * lebar;
    System.out.println("Luas = " + luas); // Output: Luas = 150
  }
}
