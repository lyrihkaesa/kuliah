public class Latihan02a {
  public static void main(String[] args) {
    System.out.print("Sistem ");
    System.out.println("Informasi");
    System.out.println("UDINUS");
  }

  // Output:
  // Sistem Informasi
  // UDINUS
}
