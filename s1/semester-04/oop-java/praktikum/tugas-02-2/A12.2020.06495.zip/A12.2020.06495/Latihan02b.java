public class Latihan02b {
  public static void main(String[] args) {
    int value = 10;
    char x;
    x = 'A';

    System.out.println(value);
    System.out.println("The value of x = " + x);

    // Output:
    // 10
    // The value of x = A
  }
}
