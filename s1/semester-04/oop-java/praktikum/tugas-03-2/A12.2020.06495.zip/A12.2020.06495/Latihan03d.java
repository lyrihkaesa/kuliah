public class Latihan03d {
    public static void main(String[] args) {
        int a = 17;
        int b = 8;
        int c = 5;

        System.out.println("a & b = " + (a & b));
        System.out.println("b | c = " + (b | c));
        System.out.println("a ^ b = " + (a ^ b));

        System.out.println("\n========================");
        System.out.println("Program : Latihan03d");
        System.out.println("NIM     : A12.2020.06495");
        System.out.println("Nama    : Kukuh Setya A.");
    }
}