public class Latihan03a {
    public static void main(String[] args) {
        int x = 5;
        System.out.println("x       = " + x); // x = 5
        System.out.println("x +=    = " + (x += 1)); // x = 5 + 1, x = 6
        System.out.println("x -=    = " + (x -= 2)); // x = 6 - 2, x = 4
        System.out.println("x *=    = " + (x *= 3)); // x = 4 * 3, x = 12
        System.out.println("x /=    = " + (x /= 4)); // x = 12 / 4, x = 3
        System.out.println("x %=    = " + (x %= 5)); // x = 3 % 5, x = 3

        System.out.println("\n========================");
        System.out.println("Program : Latihan03a");
        System.out.println("NIM     : A12.2020.06495");
        System.out.println("Nama    : Kukuh Setya A.");
    }
}