package Latihan05a;

public class CobaMhs {
    public static void main(String[] args) {
        Mhs mhsAdi = new Mhs();
        mhsAdi.setNama("Adi Sanjaya");
        System.out.println("Nama Mhs : " + mhsAdi.getNama());
    }
}