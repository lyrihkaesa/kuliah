package Latihan05a;

public class Mhs {

    // property
    private String nama;
    @SuppressWarnings("unused")
    private float ipk;

    // method

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setIpk(float ipk) {
        this.ipk = ipk;
    }

    public String getNama() {
        return this.nama;
    }
}
